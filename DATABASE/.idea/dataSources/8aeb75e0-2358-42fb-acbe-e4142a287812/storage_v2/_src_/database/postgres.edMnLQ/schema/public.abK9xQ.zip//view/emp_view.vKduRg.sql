create view emp_view(id, name, salary) as
SELECT employees.id,
       employees.name,
       employees.salary
FROM employees
WHERE (employees.department_id = 50);

alter table emp_view
    owner to postgres;

