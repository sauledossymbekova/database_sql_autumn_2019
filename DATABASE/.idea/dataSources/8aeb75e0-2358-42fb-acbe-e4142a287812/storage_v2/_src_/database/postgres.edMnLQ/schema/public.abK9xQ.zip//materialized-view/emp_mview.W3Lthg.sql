create materialized view emp_mview as
SELECT employees.id,
       employees.name,
       employees.age,
       employees.address,
       employees.salary,
       employees.department_id
FROM employees
WHERE ((((employees.name)::text >= 'A'::text) AND ((employees.name)::text <= 'H'::text)) AND
       (employees.salary = ANY (ARRAY [10000, 20000, 15000])));

alter materialized view emp_mview owner to postgres;

