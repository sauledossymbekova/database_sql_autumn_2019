create materialized view employees_by_salary as
SELECT employees.id,
       employees.name,
       employees.age,
       employees.address,
       employees.salary,
       employees.department_id
FROM employees
WHERE (employees.salary > 20000);

alter materialized view employees_by_salary owner to postgres;

