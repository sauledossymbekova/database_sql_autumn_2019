create function avg_salary(OUT average numeric) returns numeric
    language plpgsql
as
$$
BEGIN
    SELECT INTO average AVG(salary) FROM employees;
    END;
$$;

alter function avg_salary(out numeric) owner to postgres;

