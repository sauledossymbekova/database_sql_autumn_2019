create function inf_employee(ptrn_name character varying)
    returns TABLE(employee_id integer, emp_name character varying, emp_age integer, emp_address character varying, emp_salary integer, emp_department_id integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT id,name,age,address,salary,department_id
    FROM employees
    WHERE name ILIKE ptrn_name;
END;
$$;

alter function inf_employee(varchar) owner to postgres;

