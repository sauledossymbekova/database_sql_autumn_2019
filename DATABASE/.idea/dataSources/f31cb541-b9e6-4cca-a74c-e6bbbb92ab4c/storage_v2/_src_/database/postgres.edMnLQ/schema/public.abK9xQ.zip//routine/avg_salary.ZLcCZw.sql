create function avg_salary(department integer, OUT average numeric) returns numeric
    language plpgsql
as
$$
BEGIN
    SELECT INTO average AVG(salary) FROM employees
    WHERE department_id = department;
    END;
$$;

alter function avg_salary(integer, out numeric) owner to postgres;

